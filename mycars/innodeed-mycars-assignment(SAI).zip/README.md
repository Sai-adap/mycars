am used Mock-data component am installed 
npm i json-server  &&
json-server --watch Mock-data/data.json --port 3005
for geeting fetch link am used this json server

