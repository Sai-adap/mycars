import React from 'react'

const  Learn = () => {
  return (
    <div>learn</div>
  )
}

export default Learn