import React from 'react'

const Shop = () => {
  return (
    <div>shop</div>
  )
}

export default Shop